Steps to run this code:

1. Please run the index.php file in the localhost or at your server

2. Response.php is used to capture the response after success/failure of a transaction

3. Verify Payment API included.